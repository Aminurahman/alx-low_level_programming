#include "main.h"

/**
 * mul - int mul(int a, int b)
 * @a: first input value
 * @b: second input value
 *
 * Description: multiplies two integers
 * Return: Always (0).
 */

int mul(int a, int b)
{
	return (a * b);
}
