4th exercise on low level programming -c language

