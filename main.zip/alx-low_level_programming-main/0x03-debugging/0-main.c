#include "main.h"
/**
 * main - check the code
 *
 * Return: Always 0.
 */
int main(void)
{
	int i;

	i = 0;
	positive_or_negative(i);

	return (0);
}

