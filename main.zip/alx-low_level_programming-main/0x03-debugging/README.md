3rd exercise on alx low level programming -c language
