Order of m project
Arithmetic operators and how to use them
Logical operators (sometimes called boolean operators) and how to use them
Relational operators and how to use them
TRUE and FALSE values in C
Boolean operators and how to use them
if, if ... else statements
Comments
Declaring variables of types char, int, unsigned int
Assigning values to variables
Print the values of variables of type char, int, unsigned int with printf
While loop
Variables with the while loop
Printf function with varaibles
ASCII character set
The gcc flags -m32 and -m64
