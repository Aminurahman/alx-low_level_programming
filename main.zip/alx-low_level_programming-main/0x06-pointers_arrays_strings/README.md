Yet anoother task on the low level programming
