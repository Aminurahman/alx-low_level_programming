The 8th exercise
Even more pointers, arrays and strings.
