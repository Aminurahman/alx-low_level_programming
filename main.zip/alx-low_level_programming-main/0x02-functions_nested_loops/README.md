The third exercise on low level programming  (readme not updated)
