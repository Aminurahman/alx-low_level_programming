The fifth exercise on Alx low-level programming course
